# Baccarat AI — Premium
Files to deploy on GitHub Pages. Upload these files to your repo root (main branch) and enable Pages in Settings.

This project is for research/simulation only. Not a prediction tool.

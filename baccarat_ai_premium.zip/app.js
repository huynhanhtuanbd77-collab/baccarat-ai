
// Baccarat AI Premium - app.js
// Utilities
function parseSeq(text){
  if(!text) return [];
  return text.trim().toUpperCase().replace(/[\n,]+/g,' ').split(/\s+/).filter(x=>x==='P'||x==='B'||x==='T');
}

function saveHistory(arr){
  localStorage.setItem('baccarat_history_v1', JSON.stringify(arr));
}

function loadHistory(){
  try{
    const raw = localStorage.getItem('baccarat_history_v1');
    if(!raw) return [];
    return JSON.parse(raw);
  }catch(e){ return []; }
}

function detectPatterns(seq){
  const res = {counts:{P:0,B:0,T:0},runs:[],currentRun:{val:null,len:0},longestRun:{P:0,B:0,T:0},patternCounts:{},pairChanges:0};
  for(const s of seq){ res.counts[s]++; if(res.currentRun.val===s) res.currentRun.len++; else { if(res.currentRun.val!==null){ res.runs.push({...res.currentRun}); if(res.currentRun.len>res.longestRun[res.currentRun.val]) res.longestRun[res.currentRun.val]=res.currentRun.len; } res.currentRun={val:s,len:1}; } }
  if(res.currentRun.val!==null){ res.runs.push({...res.currentRun}); if(res.currentRun.len>res.longestRun[res.currentRun.val]) res.longestRun[res.currentRun.val]=res.currentRun.len; }
  function slide(k){ let c=0; for(let i=0;i+k-1<seq.length;i++){ let ok=true; for(let j=0;j<k;j++){ if(seq[i+j]!==seq[i]){ ok=false; break;} } if(ok) c++; } return c; }
  res.patternCounts['1-1']=slide(2); res.patternCounts['2-2']=slide(4); res.patternCounts['3-3']=slide(6);
  let alt=0; for(let i=0;i<seq.length-1;i++) if(seq[i]!==seq[i+1]) alt++; res.pairChanges=alt;
  return res;
}

function estimateProbabilities(counts, smoothing=1){
  const total = counts.P + counts.B + counts.T;
  const denom = total + 3 * smoothing;
  return { P: (counts.P + smoothing) / denom, B: (counts.B + smoothing) / denom, T: (counts.T + smoothing) / denom };
}

function simulateIID(prob, n){
  const out={P:0,B:0,T:0};
  for(let i=0;i<n;i++){
    const r=Math.random();
    if(r<prob.P) out.P++; else if(r<prob.P+prob.B) out.B++; else out.T++;
  }
  return out;
}

function simulateMeanReversion(seq, baseProb, n, strength=0.7){
  const total = seq.length;
  const imbalance = total>0 ? ((seq.filter(x=>x==='P').length - seq.filter(x=>x==='B').length)/total) : 0;
  const adjust = -imbalance * strength;
  let p = baseProb.P + adjust/2;
  let b = baseProb.B - adjust/2;
  p = Math.max(0.001, p); b = Math.max(0.001, b);
  const t = Math.max(0.0, baseProb.T);
  const s = p+b+t;
  p/=s; b/=s;
  const out={P:0,B:0,T:0};
  for(let i=0;i<n;i++){
    const r=Math.random();
    if(r<p) out.P++; else if(r<p+b) out.B++; else out.T++;
  }
  return out;
}

// DOM & Charts
let pieChart=null, lineChart=null;
function renderCharts(seq, counts){
  const ctxPie = document.getElementById('pieChart').getContext('2d');
  const ctxLine = document.getElementById('lineChart').getContext('2d');

  const dataPie = [counts.P, counts.B, counts.T];
  if(pieChart) pieChart.destroy();
  pieChart = new Chart(ctxPie, {
    type:'doughnut',
    data:{ labels:['P','B','T'], datasets:[{data:dataPie, backgroundColor:['#60d394','#f7a9a9','#ffe5a3']}] },
    options:{ responsive:true, plugins:{legend:{position:'bottom'}} }
  });

  // line chart: map seq to numeric (P=1,B=0,T=0.5) to show trend
  const mapping = seq.map((s,i)=>({x:i+1,y: s==='P'?1:(s==='B'?0:0.5)}));
  if(lineChart) lineChart.destroy();
  lineChart = new Chart(ctxLine, {
    type:'line',
    data:{ datasets:[{ label:'P(1)/B(0)/T(0.5)', data:mapping, fill:false, tension:0.2 }] },
    options:{ scales:{ x:{ type:'linear', title:{display:true,text:'Ván'} }, y:{ min:0, max:1, ticks:{stepSize:0.25} } }, plugins:{legend:{display:false}} }
  });
}

function updateStatsDisplay(seq, stats, probs){
  const el = document.getElementById('statsArea');
  const total = seq.length;
  let html = '<table><tr><th>Thống kê</th><th>Giá trị</th></tr>';
  html += `<tr><td>Tổng ván</td><td>${total}</td></tr>`;
  html += `<tr><td>P</td><td>${stats.counts.P} (${(stats.counts.P/Math.max(1,total)*100).toFixed(2)}%)</td></tr>`;
  html += `<tr><td>B</td><td>${stats.counts.B} (${(stats.counts.B/Math.max(1,total)*100).toFixed(2)}%)</td></tr>`;
  html += `<tr><td>T</td><td>${stats.counts.T} (${(stats.counts.T/Math.max(1,total)*100).toFixed(2)}%)</td></tr>`;
  html += `<tr><td>Longest run P</td><td>${stats.longestRun.P}</td></tr>`;
  html += `<tr><td>Longest run B</td><td>${stats.longestRun.B}</td></tr>`;
  html += `<tr><td>Alternations (changes)</td><td>${stats.pairChanges}</td></tr>`;
  html += '</table>';

  html += '<h4>Pattern counts</h4><ul>';
  html += `<li>1-1 (2 cùng): ${stats.patternCounts['1-1']}</li>`;
  html += `<li>2-2 (4 cùng): ${stats.patternCounts['2-2']}</li>`;
  html += `<li>3-3 (6 cùng): ${stats.patternCounts['3-3']}</li>`;
  html += '</ul>';

  html += `<h4>Xác suất (smoothing)</h4><p>P=${(probs.P*100).toFixed(2)}% | B=${(probs.B*100).toFixed(2)}% | T=${(probs.T*100).toFixed(2)}%</p>`;

  document.getElementById('statsArea').innerHTML = html;
}

function showHistoryTable(seq){
  const wrap = document.getElementById('historyTableWrapper');
  if(seq.length===0){ wrap.innerHTML='<p class="muted">Chưa có lịch sử.</p>'; return; }
  let html = '<table><tr><th>Ván</th><th>Kết quả</th></tr>';
  seq.forEach((v,i)=>{ html += `<tr><td>${i+1}</td><td>${v}</td></tr>`; });
  html += '</table>';
  wrap.innerHTML = html;
}

// Main actions
document.getElementById('btnLoad').addEventListener('click', ()=>{ 
  const raw = document.getElementById('inputSeq').value;
  const seq = parseSeq(raw);
  const history = loadHistory();
  const combined = seq.length? seq : history;
  saveHistory(combined);
  renderAll(combined);
});

document.getElementById('btnAppend').addEventListener('click', ()=>{
  const raw = document.getElementById('inputSeq').value;
  const seq = parseSeq(raw);
  if(seq.length===0) return alert('Chưa nhập ván để thêm.');
  const history = loadHistory();
  const newHist = history.concat(seq);
  saveHistory(newHist);
  renderAll(newHist);
  document.getElementById('inputSeq').value = '';
});

document.getElementById('btnClear').addEventListener('click', ()=>{
  if(!confirm('Xóa toàn bộ lịch sử?')) return;
  saveHistory([]);
  renderAll([]);
});

document.getElementById('btnShowHistory').addEventListener('click', ()=> showHistoryTable(loadHistory()));

document.getElementById('btnExport').addEventListener('click', ()=>{
  const hist = loadHistory();
  const blob = new Blob([JSON.stringify(hist)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download='baccarat_history.json'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
});

document.getElementById('btnImport').addEventListener('click', ()=> document.getElementById('fileInput').click());
document.getElementById('fileInput').addEventListener('change', (e)=>{
  const f = e.target.files[0]; if(!f) return;
  const reader = new FileReader();
  reader.onload = function(ev){ try{ const arr = JSON.parse(ev.target.result); if(Array.isArray(arr)) { saveHistory(arr); renderAll(arr); alert('Import thành công.'); } else alert('File không hợp lệ.'); } catch(err){ alert('File JSON lỗi.'); } };
  reader.readAsText(f);
});

document.getElementById('btnDownloadHtml').addEventListener('click', ()=>{
  const blob = new Blob([document.documentElement.outerHTML], {type:'text/html'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download='baccarat_ai_page.html'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
});

// Simulations
document.getElementById('btnSimIID').addEventListener('click', ()=>{
  const n = Math.max(100, parseInt(document.getElementById('nSim').value)||10000);
  const seq = loadHistory();
  const stats = detectPatterns(seq);
  const probs = estimateProbabilities(stats.counts, 1);
  const sim = simulateIID(probs, n);
  const out = {IID: {P: sim.P, B: sim.B, T: sim.T, pctP: sim.P/n, pctB: sim.B/n, pctT: sim.T/n}};
  document.getElementById('simResult').innerHTML = renderSimOut(out, n, 'IID');
});

document.getElementById('btnSimMR').addEventListener('click', ()=>{
  const n = Math.max(100, parseInt(document.getElementById('nSim').value)||10000);
  const seq = loadHistory();
  const stats = detectPatterns(seq);
  const probs = estimateProbabilities(stats.counts, 1);
  const sim = simulateMeanReversion(seq, probs, n, 0.7);
  const out = {MR: {P: sim.P, B: sim.B, T: sim.T, pctP: sim.P/n, pctB: sim.B/n, pctT: sim.T/n}};
  document.getElementById('simResult').innerHTML = renderSimOut(out, n, 'Mean-Reversion');
});

function renderSimOut(out, n, label){
  let html = `<h4>Mô phỏng (${label}) — ${n} lặp</h4>`;
  const keys = Object.keys(out)[0];
  const o = out[keys];
  html += `<p>P: ${o.P} (${(o.pctP*100).toFixed(2)}%) | B: ${o.B} (${(o.pctB*100).toFixed(2)}%) | T: ${o.T} (${(o.pctT*100).toFixed(2)}%)</p>`;
  html += '<div style="display:flex;gap:8px"><div style="flex:1"><div style="height:14px;background:#e6eef6;border-radius:6px"><div style="height:100%;background:#60d394;width:'+(o.pctP*100)+'%"></div></div><small>P</small></div>';
  html += '<div style="flex:1"><div style="height:14px;background:#e6eef6;border-radius:6px"><div style="height:100%;background:#f7a9a9;width:'+(o.pctB*100)+'%"></div></div><small>B</small></div>';
  html += '<div style="flex:1"><div style="height:14px;background:#e6eef6;border-radius:6px"><div style="height:100%;background:#ffdf8a;width:'+(o.pctT*100)+'%"></div></div><small>T</small></div></div>';
  html += '<p class="note">Đây là kết quả mô phỏng dùng để phân tích xu hướng — không phải dự đoán chắc chắn.</p>';
  return html;
}

// Render everything
function renderAll(seq){
  const s = seq || [];
  const stats = detectPatterns(s);
  const probs = estimateProbabilities(stats.counts, 1);
  renderCharts(s, stats.counts);
  updateStatsDisplay(s, stats, probs);
}

// Init
document.addEventListener('DOMContentLoaded', ()=>{
  const hist = loadHistory();
  renderAll(hist);
});
